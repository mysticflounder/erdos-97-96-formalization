#!/usr/bin/env python3
"""Exact classification of cyclic three-row Berge triangles under strict Kalmanson.

Six distinct boundary vertices are labelled by three row centres A,B,C and three
pairwise-shared support points X,Y,Z, with row equalities

  row(A): d(A,Y) = d(A,Z)
  row(B): d(B,X) = d(B,Y)
  row(C): d(C,X) = d(C,Z).

The script enumerates all 720 linear cyclic listings, quotients by dihedral order
and the S3 automorphism group of the incidence triangle, and verifies every orbit
exactly.  Infeasible orbits carry a positive dependence of two or three strict
Kalmanson inequalities.  Every remaining orbit carries an explicit positive
rational distance assignment satisfying all strict Kalmanson and strict triangle
inequalities after the three row equalities are imposed.
"""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations, permutations
from pathlib import Path
from typing import Any, Iterable

LABELS = ("A", "B", "C", "X", "Y", "Z")
CENTERS = ("A", "B", "C")
PAIR_POINT = {
    frozenset(("B", "C")): "X",
    frozenset(("A", "B")): "Y",
    frozenset(("A", "C")): "Z",
}
ROW_EQUALITIES = (
    (("A", "Y"), ("A", "Z")),
    (("B", "X"), ("B", "Y")),
    (("C", "X"), ("C", "Z")),
)


def edge(u: str, v: str) -> tuple[str, str]:
    if u == v:
        raise ValueError(f"degenerate edge {u}-{v}")
    return tuple(sorted((u, v)))


class UnionFind:
    def __init__(self, values: Iterable[tuple[str, str]]) -> None:
        self.parent = {x: x for x in values}

    def find(self, x: tuple[str, str]) -> tuple[str, str]:
        p = self.parent[x]
        if p != x:
            self.parent[x] = self.find(p)
        return self.parent[x]

    def union(self, a: tuple[str, str], b: tuple[str, str]) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[rb] = ra


def build_components() -> tuple[list[tuple[tuple[str, str], ...]], dict[tuple[str, str], int]]:
    edges = [edge(a, b) for a, b in combinations(LABELS, 2)]
    uf = UnionFind(edges)
    for left, right in ROW_EQUALITIES:
        uf.union(edge(*left), edge(*right))
    grouped: dict[tuple[str, str], list[tuple[str, str]]] = defaultdict(list)
    for item in edges:
        grouped[uf.find(item)].append(item)
    components = sorted(
        (tuple(sorted(items)) for items in grouped.values()),
        key=lambda items: (items[0], len(items), items),
    )
    edge_to_component = {
        item: index for index, component in enumerate(components) for item in component
    }
    return components, edge_to_component


COMPONENTS, EDGE_TO_COMPONENT = build_components()


def component_name(component: tuple[tuple[str, str], ...]) -> str:
    return "=".join("".join(item) for item in component)


COMPONENT_NAMES = [component_name(component) for component in COMPONENTS]


def incidence_automorphisms() -> list[dict[str, str]]:
    result: list[dict[str, str]] = []
    for target_centers in permutations(CENTERS):
        mapping = {CENTERS[i]: target_centers[i] for i in range(3)}
        for pair, point in PAIR_POINT.items():
            image_pair = frozenset(mapping[c] for c in pair)
            mapping[point] = PAIR_POINT[image_pair]
        result.append(mapping)
    return result


AUTOMORPHISMS = incidence_automorphisms()


def rotations(values: list[str]) -> Iterable[list[str]]:
    for index in range(len(values)):
        yield values[index:] + values[:index]


def canonical_order(order: Iterable[str]) -> tuple[str, ...]:
    values = list(order)
    candidates: list[tuple[str, ...]] = []
    for automorphism in AUTOMORPHISMS:
        mapped = [automorphism[x] for x in values]
        for oriented in (mapped, list(reversed(mapped))):
            candidates.extend(tuple(rotation) for rotation in rotations(oriented))
    return min(candidates)


def coefficient_vector(
    lhs: Iterable[tuple[str, str]], rhs: Iterable[tuple[str, str]]
) -> tuple[int, ...]:
    values = [0] * len(COMPONENTS)
    for item in lhs:
        values[EDGE_TO_COMPONENT[edge(*item)]] += 1
    for item in rhs:
        values[EDGE_TO_COMPONENT[edge(*item)]] -= 1
    return tuple(values)


def inequality_payload(
    *,
    index: int,
    kind: str,
    vertices: tuple[str, ...],
    family: str,
    lhs: tuple[tuple[str, str], ...],
    rhs: tuple[tuple[str, str], ...],
) -> dict[str, Any]:
    vector = coefficient_vector(lhs, rhs)
    return {
        "index": index,
        "kind": kind,
        "vertices": list(vertices),
        "family": family,
        "lhs": ["".join(item) for item in lhs],
        "rhs": ["".join(item) for item in rhs],
        "reduced": {
            COMPONENT_NAMES[i]: value for i, value in enumerate(vector) if value
        },
        "vector": list(vector),
    }


def generate_inequalities(order: tuple[str, ...], include_triangle: bool) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for positions in combinations(range(6), 4):
        a, b, c, d = (order[index] for index in positions)
        lhs = (edge(a, c), edge(b, d))
        rhs_families = (
            ("ab_cd", (edge(a, b), edge(c, d))),
            ("ad_bc", (edge(a, d), edge(b, c))),
        )
        for family, rhs in rhs_families:
            output.append(
                inequality_payload(
                    index=len(output),
                    kind="kalmanson",
                    vertices=(a, b, c, d),
                    family=family,
                    lhs=lhs,
                    rhs=rhs,
                )
            )
    if include_triangle:
        for a, b, c in combinations(order, 3):
            forms = (
                (f"apex_{a}", (edge(a, b), edge(a, c)), (edge(b, c),)),
                (f"apex_{b}", (edge(a, b), edge(b, c)), (edge(a, c),)),
                (f"apex_{c}", (edge(a, c), edge(b, c)), (edge(a, b),)),
            )
            for family, lhs, rhs in forms:
                output.append(
                    inequality_payload(
                        index=len(output),
                        kind="triangle",
                        vertices=(a, b, c),
                        family=family,
                        lhs=lhs,
                        rhs=rhs,
                    )
                )
    return output


def integer_null_weight(vectors: list[tuple[int, ...]]) -> list[int] | None:
    """Return primitive positive integer weights summing the vectors to zero.

    The search is deliberately limited to at most three vectors; exact minors are
    enough and avoid any floating-point or external solver dependency.
    """

    if len(vectors) == 1:
        return [1] if all(value == 0 for value in vectors[0]) else None
    if len(vectors) == 2:
        first, second = vectors
        ratio: Fraction | None = None
        for x, y in zip(first, second):
            if x == 0 and y == 0:
                continue
            if x == 0 or y == 0:
                return None
            candidate = Fraction(-y, x)
            if candidate <= 0:
                return None
            if ratio is None:
                ratio = candidate
            elif ratio != candidate:
                return None
        if ratio is None:
            return [1, 1]
        # ratio*x + y = 0, so weights are (ratio, 1).
        weights = [ratio, Fraction(1)]
    elif len(vectors) == 3:
        # Find a nonzero 2x2 minor and use the three signed cofactors as a null vector.
        columns = list(zip(*vectors))
        candidate_weights: list[Fraction] | None = None
        for i, j in combinations(range(len(columns)), 2):
            a = [[vectors[row][i], vectors[row][j]] for row in range(3)]
            cofactors = [
                Fraction(a[1][0] * a[2][1] - a[1][1] * a[2][0]),
                Fraction(-(a[0][0] * a[2][1] - a[0][1] * a[2][0])),
                Fraction(a[0][0] * a[1][1] - a[0][1] * a[1][0]),
            ]
            if any(cofactors):
                candidate_weights = cofactors
                break
        if candidate_weights is None:
            return None
        weights = candidate_weights
        if all(weight < 0 for weight in weights):
            weights = [-weight for weight in weights]
        if not all(weight > 0 for weight in weights):
            return None
        for column in range(len(vectors[0])):
            if sum(weights[row] * vectors[row][column] for row in range(3)) != 0:
                return None
    else:
        raise ValueError("exact dependency search supports at most three vectors")

    denominator_lcm = 1
    for weight in weights:
        denominator_lcm = math.lcm(denominator_lcm, weight.denominator)
    integers = [int(weight * denominator_lcm) for weight in weights]
    divisor = 0
    for value in integers:
        divisor = math.gcd(divisor, value)
    return [value // divisor for value in integers]


def minimal_kalmanson_dependency(order: tuple[str, ...]) -> dict[str, Any] | None:
    inequalities = generate_inequalities(order, include_triangle=False)
    vectors = [tuple(item["vector"]) for item in inequalities]
    for size in (1, 2, 3):
        for indices in combinations(range(len(vectors)), size):
            selected = [vectors[index] for index in indices]
            weights = integer_null_weight(selected)
            if weights is None:
                continue
            return {
                "size": size,
                "indices": list(indices),
                "weights": weights,
                "inequalities": [inequalities[index] for index in indices],
                "sum_vector": [
                    sum(weights[row] * selected[row][column] for row in range(size))
                    for column in range(len(COMPONENTS))
                ],
            }
    return None


# Exact certificates for all Kalmanson+triangle-feasible order orbits.  Values are
# indexed by COMPONENT_NAMES and normalized to sum to one.
RATIONAL_WITNESSES: dict[tuple[str, ...], tuple[str, ...]] = {
    ("A", "B", "C", "X", "Z", "Y"): (
        "5/108", "2/27", "1/9", "2/27", "5/108", "11/108", "1/12", "2/27", "1/9", "7/54", "2/27", "2/27"
    ),
    ("A", "B", "C", "Y", "Z", "X"): (
        "5/84", "2/21", "5/84", "3/28", "5/84", "2/21", "5/42", "3/28", "5/84", "2/21", "1/14", "1/14"
    ),
    ("A", "B", "X", "C", "Y", "Z"): (
        "5/124", "5/62", "13/124", "9/124", "9/124", "5/62", "3/31", "11/124", "5/124", "7/62", "9/62", "2/31"
    ),
    ("A", "B", "X", "C", "Z", "Y"): (
        "5/132", "1/11", "7/66", "2/33", "1/12", "1/12", "3/44", "2/33", "7/66", "3/22", "7/66", "2/33"
    ),
    ("A", "B", "Y", "C", "Z", "X"): (
        "5/108", "1/12", "5/108", "11/108", "2/27", "2/27", "1/9", "2/27", "2/27", "1/9", "2/27", "7/54"
    ),
    ("A", "B", "Y", "Z", "C", "X"): (
        "5/102", "3/34", "5/102", "11/102", "5/51", "4/51", "5/51", "1/17", "5/51", "2/17", "5/51", "1/17"
    ),
    ("A", "B", "Z", "C", "Y", "X"): (
        "5/108", "11/108", "2/27", "5/54", "5/54", "11/108", "7/108", "1/12", "5/108", "1/18", "7/54", "1/9"
    ),
    ("A", "X", "B", "Y", "C", "Z"): (
        "4/51", "4/51", "5/102", "3/34", "4/51", "5/102", "13/102", "3/34", "5/102", "4/51", "2/17", "2/17"
    ),
    ("A", "Y", "B", "X", "C", "Z"): (
        "4/45", "4/45", "1/10", "1/18", "4/45", "1/18", "1/10", "1/18", "1/10", "4/45", "4/45", "4/45"
    ),
}


def verify_witness(order: tuple[str, ...], values_text: tuple[str, ...]) -> dict[str, Any]:
    values = [Fraction(text) for text in values_text]
    if len(values) != len(COMPONENTS):
        raise AssertionError(f"{order}: witness length mismatch")
    if sum(values) != 1:
        raise AssertionError(f"{order}: witness is not normalized")
    if not all(value > 0 for value in values):
        raise AssertionError(f"{order}: witness has a nonpositive distance")
    inequalities = generate_inequalities(order, include_triangle=True)
    slacks: list[Fraction] = []
    for item in inequalities:
        vector = item["vector"]
        slack = sum(Fraction(vector[i]) * values[i] for i in range(len(values)))
        if slack <= 0:
            raise AssertionError(f"{order}: non-strict witness inequality {item}")
        slacks.append(slack)
    return {
        "component_values": {
            COMPONENT_NAMES[i]: str(value) for i, value in enumerate(values)
        },
        "normalization": "1",
        "strict_inequality_count": len(inequalities),
        "minimum_strict_slack": str(min(slacks)),
        "minimum_component": str(min(values)),
    }


def classify() -> dict[str, Any]:
    orbit_members: dict[tuple[str, ...], list[tuple[str, ...]]] = defaultdict(list)
    for order in permutations(LABELS):
        orbit_members[canonical_order(order)].append(order)

    records: list[dict[str, Any]] = []
    for representative in sorted(orbit_members):
        dependency = minimal_kalmanson_dependency(representative)
        if dependency is not None:
            if any(dependency["sum_vector"]):
                raise AssertionError("purported strict contradiction does not sum to zero")
            verdict = (
                "INFEASIBLE_BY_TWO_STRICT_KALMANSON"
                if dependency["size"] == 2
                else "INFEASIBLE_BY_THREE_STRICT_KALMANSON"
            )
            certificate: dict[str, Any] = dependency
        else:
            values = RATIONAL_WITNESSES.get(representative)
            if values is None:
                raise AssertionError(f"missing exact rational witness for {representative}")
            verdict = "EXACT_RATIONAL_KALMANSON_AND_TRIANGLE_WITNESS"
            certificate = verify_witness(representative, values)
        records.append(
            {
                "representative_order": list(representative),
                "orbit_size": len(orbit_members[representative]),
                "verdict": verdict,
                "certificate": certificate,
            }
        )

    verdict_counts = Counter(record["verdict"] for record in records)
    if sum(record["orbit_size"] for record in records) != math.factorial(6):
        raise AssertionError("orbit census does not cover all 720 orders")
    return {
        "schema": "p97-berge-triangle-kalmanson-order-classification/v1",
        "abstract_labels": list(LABELS),
        "row_equalities": [
            ["".join(left), "".join(right)] for left, right in ROW_EQUALITIES
        ],
        "distance_components": {
            COMPONENT_NAMES[index]: ["".join(item) for item in component]
            for index, component in enumerate(COMPONENTS)
        },
        "quotient_group": "dihedral cyclic order x S3 incidence automorphisms",
        "linear_orders": math.factorial(6),
        "order_orbits": len(records),
        "verdict_counts": dict(sorted(verdict_counts.items())),
        "infeasible_orbits": sum(record["verdict"].startswith("INFEASIBLE") for record in records),
        "two_kalmanson_orbits": sum("TWO" in record["verdict"] for record in records),
        "three_kalmanson_orbits": sum("THREE" in record["verdict"] for record in records),
        "feasible_relaxation_orbits": sum(record["verdict"].startswith("EXACT") for record in records),
        "orbits": records,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    payload = classify()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {
                key: payload[key]
                for key in (
                    "linear_orders",
                    "order_orbits",
                    "infeasible_orbits",
                    "two_kalmanson_orbits",
                    "three_kalmanson_orbits",
                    "feasible_relaxation_orbits",
                    "verdict_counts",
                )
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
