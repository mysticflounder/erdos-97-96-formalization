#!/usr/bin/env python3
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
def read_bank(p):
 with p.open() as f:
  n,m=map(int,f.readline().split());out=[]
  for _ in range(m):
   xs=list(map(int,f.readline().split()));k=xs[0];out.append(tuple((xs[1+2*i],xs[2+2*i]) for i in range(k)))
 return n,set(out)
def violates(cl,rows):return all((mask & ~rows[c])==0 for c,mask in cl)
def load_rows(p,n):
 d=json.loads(p.read_text());assert d['status']=='EXACT_MASTER_SAT'; rows={int(c):sum(1<<x for x in pts) for c,pts in d['supports'].items()}
 assert set(rows)==set(range(n))
 for c,m in rows.items():assert m.bit_count()==4 and not(m>>c&1)
 return rows
n,base=read_bank(ROOT/'generated/base.txt');_,br2=read_bank(ROOT/'generated/base-r2.txt');_,br3=read_bank(ROOT/'generated/base-r3.txt');_,full=read_bank(ROOT/'generated/full.txt')
r2=br2-base;r3=br3-base
out={'schema':'p97-n10-incremental-witness-audit/v1','status':'PASS','records':[]}
for nm,allowed in [('base',base),('base-r2',br2),('base-r3',br3)]:
 rows=load_rows(ROOT/f'results/incremental-{nm}.json',n)
 counts={'base':sum(violates(x,rows) for x in base),'r2':sum(violates(x,rows) for x in r2),'r3':sum(violates(x,rows) for x in r3),'full':sum(violates(x,rows) for x in full)}
 assert sum(violates(x,rows) for x in allowed)==0
 assert counts['full']>0
 out['records'].append({'bank':nm,'violations':counts})
(ROOT/'results/incremental-witness-audit.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
