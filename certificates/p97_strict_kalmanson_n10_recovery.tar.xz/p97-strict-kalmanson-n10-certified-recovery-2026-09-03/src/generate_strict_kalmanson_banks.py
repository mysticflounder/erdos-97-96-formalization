#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, hashlib
from itertools import combinations
from pathlib import Path
from sum_node_cycle_master import grouped_nogoods

def shared_pair_nonalternation(n:int):
    raw=[]
    for a,b,c,d in combinations(range(n),4):
        for x,y,p,q in ((a,b,c,d),(c,d,a,b),(a,d,b,c),(b,c,a,d)):
            raw.append(tuple(sorted(((x,p),(x,q),(y,p),(y,q)))))
    return sorted(set(raw))

def group(atoms):
    g={}
    for c,p in atoms:g[c]=g.get(c,0)|(1<<p)
    return tuple(sorted(g.items()))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--n',type=int,required=True);ap.add_argument('--incidence',action='store_true');ap.add_argument('--output',type=Path,required=True);ap.add_argument('--manifest',type=Path,required=True);a=ap.parse_args()
    berge=grouped_nogoods(a.n,[],include_berge=True,include_incidence=a.incidence)
    shared=[group(x) for x in shared_pair_nonalternation(a.n)]
    allc=sorted(set(berge)|set(shared))
    with a.output.open('w') as f:
        f.write(f'{a.n} {len(allc)}\n')
        for cl in allc:
            f.write(str(len(cl)))
            for c,m in cl:f.write(f' {c} {m}')
            f.write('\n')
    data=a.output.read_bytes()
    man={'schema':'p97-strict-kalmanson-static-bank/v1','n':a.n,'complete_berge_grouped':len(berge),'shared_pair_nonalternating':len(shared),'total_unique':len(allc),'incidence':a.incidence,'file':a.output.name,'sha256':hashlib.sha256(data).hexdigest()}
    a.manifest.write_text(json.dumps(man,sort_keys=True,separators=(',',':'))+'\n')
    print(json.dumps(man,indent=2))
if __name__=='__main__':main()
