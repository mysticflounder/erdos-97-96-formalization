#!/usr/bin/env python3
"""Exact row-system master with quotient sum-node cycle pruning.

A row at centre c identifies the four distance variables d(c,p) selected by
that row.  Equality closure is maintained by a rollback union-find.  For each
strict Kalmanson inequality (+u +v -x -y > 0), the inequality is identically
zero in the quotient exactly when the multiset of equality components of
{u,v} equals that of {x,y}.  Such a collapse is monotone under further row
choices, so it is rejected immediately.

Each reduced strict Kalmanson form is viewed as a directed comparison between
two quotient edge-sums.  Any directed cycle is an exact positive cancellation.
The master may also enforce the complete finite Berge-triangle no-good bank.
A sound rotational symmetry breaker chooses a representative whose centre-0
relative row signature is minimum among all centres.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import time
from collections import Counter
from itertools import combinations
from pathlib import Path
from typing import Any, Iterable

from berge_triangle_nogood_family import generate as generate_berge_family


def cbytes(v: Any) -> bytes:
    return (json.dumps(v, sort_keys=True, separators=(",", ":")) + "\n").encode()


def edge(a: int, b: int) -> tuple[int, int]:
    return (a, b) if a < b else (b, a)


def relative_signature(n: int, centre: int, row_mask: int) -> int:
    out = 0
    for p in range(n):
        if row_mask >> p & 1:
            out |= 1 << ((p - centre) % n)
    return out


def reflected_signature(n: int, signature: int) -> int:
    out = 0
    for k in range(1, n):
        if signature >> k & 1:
            out |= 1 << ((-k) % n)
    return out


def canonical_dihedral_signature(n: int, centre: int, row_mask: int) -> int:
    signature = relative_signature(n, centre, row_mask)
    return min(signature, reflected_signature(n, signature))


class RollbackDSU:
    def __init__(self, n: int) -> None:
        self.parent = list(range(n))
        self.size = [1] * n
        self.stack: list[tuple[int, int, int] | None] = []

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            x = self.parent[x]
        return x

    def snapshot(self) -> int:
        return len(self.stack)

    def union(self, a: int, b: int) -> bool:
        a, b = self.find(a), self.find(b)
        if a == b:
            self.stack.append(None)
            return False
        if self.size[a] < self.size[b]:
            a, b = b, a
        self.stack.append((b, a, self.size[a]))
        self.parent[b] = a
        self.size[a] += self.size[b]
        return True

    def rollback(self, snap: int) -> None:
        while len(self.stack) > snap:
            item = self.stack.pop()
            if item is None:
                continue
            b, a, old_size = item
            self.parent[b] = b
            self.size[a] = old_size

    def canonical_partition(self) -> tuple[int, ...]:
        labels: dict[int, int] = {}
        out = []
        for x in range(len(self.parent)):
            r = self.find(x)
            if r not in labels:
                labels[r] = len(labels)
            out.append(labels[r])
        return tuple(out)


def geometric_incidence_nogoods(n: int) -> tuple[list[list[tuple[int, int]]], dict[str, int]]:
    """Circle/bisector incidence consequences valid for strict-convex Euclidean rows.

    * Two distinct selected circles meet in at most two carrier points.
    * A fixed support pair has at most two carrier centres, since all such
      centres lie on its perpendicular bisector and a line meets a strictly
      convex vertex set in at most two points.
    """
    raw: list[list[tuple[int, int]]] = []
    row_intersection = 0
    pair_codegree = 0
    for c, d in combinations(range(n), 2):
        for pts in combinations([p for p in range(n) if p not in {c, d}], 3):
            raw.append([(c, p) for p in pts] + [(d, p) for p in pts])
            row_intersection += 1
    for p, q in combinations(range(n), 2):
        for centres in combinations([c for c in range(n) if c not in {p, q}], 3):
            raw.append([(c, p) for c in centres] + [(c, q) for c in centres])
            pair_codegree += 1
    return raw, {"row_intersection_at_most_two": row_intersection, "pair_codegree_at_most_two": pair_codegree}


def grouped_nogoods(n: int, learned: Iterable[Iterable[Iterable[int]]] = (), include_berge: bool = True, include_incidence: bool = False) -> list[tuple[tuple[int, int], ...]]:
    raw: list[list[tuple[int, int]]] = []
    if include_berge:
        family = generate_berge_family(list(range(n)), "all")
        for flat in family["clauses"]:
            raw.append([(int(flat[i]), int(flat[i + 1])) for i in range(0, len(flat), 2)])
    if include_incidence:
        incidence, _ = geometric_incidence_nogoods(n)
        raw.extend(incidence)
    for clause in learned:
        raw.append([(int(a), int(b)) for a, b in clause])
    unique: set[tuple[tuple[int, int], ...]] = set()
    for atoms in raw:
        grouped: dict[int, int] = {}
        for c, p in atoms:
            grouped[c] = grouped.get(c, 0) | (1 << p)
        unique.add(tuple(sorted(grouped.items())))
    return sorted(unique)


def solve(n: int, learned: list[list[list[int]]], time_limit: float | None, state_limit: int | None, include_berge: bool = True, include_incidence: bool = False, symmetry: str = "dihedral", two_k: bool = True) -> dict[str, Any]:
    started = time.time()
    edges = list(combinations(range(n), 2))
    edge_index = {e: i for i, e in enumerate(edges)}
    kalmanson: list[tuple[str, tuple[int, int], tuple[int, int], tuple[int, int], tuple[int, int]]] = []
    for a, b, c, d in combinations(range(n), 4):
        kalmanson.append((f"K1_{a}_{b}_{c}_{d}", edge(a, c), edge(b, d), edge(a, b), edge(c, d)))
        kalmanson.append((f"K2_{a}_{b}_{c}_{d}", edge(a, c), edge(b, d), edge(a, d), edge(b, c)))
    kidx = [(name, edge_index[p1], edge_index[p2], edge_index[m1], edge_index[m2]) for name, p1, p2, m1, m2 in kalmanson]

    clauses = grouped_nogoods(n, learned, include_berge, include_incidence)
    m = len(clauses)
    centre_masks: list[int] = []
    required = [[0] * m for _ in range(n)]
    for i, clause in enumerate(clauses):
        cm = 0
        for c, mask in clause:
            cm |= 1 << c
            required[c][i] = mask
        centre_masks.append(cm)
    # Group clause bitsets by their centre pattern.  This makes all later
    # variable-order scores pure big-integer bit operations rather than a scan
    # over every clause at every search state.
    pattern_bits: list[dict[int, int]] = [dict() for _ in range(n)]
    exact_centre_mask_bits: dict[int, int] = {}
    for i, cm in enumerate(centre_masks):
        exact_centre_mask_bits[cm] = exact_centre_mask_bits.get(cm, 0) | (1 << i)
        for c in range(n):
            if cm >> c & 1:
                residual = cm & ~(1 << c)
                pattern_bits[c][residual] = pattern_bits[c].get(residual, 0) | (1 << i)

    completed = [0] * (1 << n)
    for unassigned in range(1 << n):
        bits = 0
        for cm, clause_bits in exact_centre_mask_bits.items():
            if cm & unassigned == 0:
                bits |= clause_bits
        completed[unassigned] = bits

    score_buckets = [[[0, 0, 0, 0] for _ in range(1 << n)] for _ in range(n)]
    for c in range(n):
        for unassigned in range(1 << n):
            after = unassigned & ~(1 << c)
            buckets = score_buckets[c][unassigned]
            for residual, clause_bits in pattern_bits[c].items():
                buckets[min((residual & after).bit_count(), 3)] |= clause_bits

    domains: dict[int, list[int]] = {}
    row_edges: dict[tuple[int, int], tuple[int, ...]] = {}
    incompatible: dict[tuple[int, int], int] = {}
    for c in range(n):
        rows = []
        for subset in combinations([p for p in range(n) if p != c], 4):
            mask = sum(1 << p for p in subset)
            rows.append(mask)
            row_edges[c, mask] = tuple(edge_index[edge(c, p)] for p in subset)
            bad = 0
            for i in range(m):
                need = required[c][i]
                if need and need & ~mask:
                    bad |= 1 << i
            incompatible[c, mask] = bad
        domains[c] = rows

    dsu = RollbackDSU(len(edges))
    all_active = (1 << m) - 1
    states = transitions = collapse_prunes = nogood_prunes = cache_hits = 0
    collapse_name_counts: Counter[str] = Counter()
    failed: set[tuple[int, int, tuple[int, ...]]] = set()
    assignment: dict[int, int] = {}
    limit_reason: str | None = None

    def first_collapse() -> str | None:
        # A strict Kalmanson form is a comparison between two multisets of
        # quotient distance components.  After cancelling common components,
        # record an edge negative_sum -> positive_sum.  A directed cycle adds
        # the corresponding strict inequalities to 0 > 0 exactly.
        graph: dict[tuple[int, ...], list[tuple[tuple[int, ...], str]]] = {}
        for name, p1, p2, m1, m2 in kidx:
            counts: dict[int, int] = {}
            for idx, coefficient in ((p1, 1), (p2, 1), (m1, -1), (m2, -1)):
                root = dsu.find(idx)
                counts[root] = counts.get(root, 0) + coefficient
            vector = tuple(sorted((root, coefficient) for root, coefficient in counts.items() if coefficient))
            if not vector:
                return f"SINGLE:{name}"
            positive = tuple(root for root, coefficient in vector for _ in range(max(coefficient, 0)))
            negative = tuple(root for root, coefficient in vector for _ in range(max(-coefficient, 0)))
            # Total coefficient is zero for every Kalmanson form.
            if not positive or not negative or len(positive) != len(negative):
                raise RuntimeError(f"malformed quotient comparison {name}: {vector}")
            graph.setdefault(negative, []).append((positive, name))

        if not two_k:
            return None

        colour: dict[tuple[int, ...], int] = {}
        parent: dict[tuple[int, ...], tuple[tuple[int, ...], str]] = {}

        def visit(node: tuple[int, ...]) -> str | None:
            colour[node] = 1
            for nxt, edge_name in graph.get(node, []):
                state = colour.get(nxt, 0)
                if state == 0:
                    parent[nxt] = (node, edge_name)
                    found = visit(nxt)
                    if found is not None:
                        return found
                elif state == 1:
                    # Recover only a compact kind/count marker; exact cycle
                    # reconstruction is added to witness-oriented runs.
                    length = 1
                    cur = node
                    while cur != nxt:
                        cur = parent[cur][0]
                        length += 1
                    return f"CYCLE{length}:{edge_name}"
            colour[node] = 2
            return None

        for node in graph:
            if colour.get(node, 0) == 0:
                found = visit(node)
                if found is not None:
                    return found
        return None

    class Limit(Exception):
        pass

    def check_limit() -> None:
        nonlocal limit_reason
        if state_limit is not None and states > state_limit:
            limit_reason = "state_limit"
            raise Limit
        if time_limit is not None and states % 1024 == 0 and time.time() - started > time_limit:
            limit_reason = "time_limit"
            raise Limit

    def search(unassigned: int, active: int, min_sig: int) -> bool:
        nonlocal states, transitions, collapse_prunes, nogood_prunes, cache_hits, limit_reason
        states += 1
        check_limit()
        if unassigned == 0:
            return True
        key = (unassigned, active, dsu.canonical_partition())
        if key in failed:
            cache_hits += 1
            return False

        best = None
        best_domain: list[int] | None = None
        best_score: tuple[int, int, int, int, int] | None = None
        for c in range(n):
            if not (unassigned >> c & 1):
                continue
            allowed = domains[c]
            if c != 0 and symmetry == "rotation":
                allowed = [r for r in allowed if relative_signature(n, c, r) >= min_sig]
            elif c != 0 and symmetry == "dihedral":
                allowed = [r for r in allowed if canonical_dihedral_signature(n, c, r) >= min_sig]
            after = unassigned & ~(1 << c)
            buckets = score_buckets[c][unassigned]
            one = (active & buckets[0]).bit_count()
            two = (active & buckets[1]).bit_count()
            three = (active & buckets[2]).bit_count()
            total = one + two + three + (active & buckets[3]).bit_count()
            score = (one, two, three, total, -len(allowed))
            if best_score is None or score > best_score:
                best_score, best, best_domain = score, c, allowed
        assert best is not None and best_domain is not None
        c = best
        after = unassigned & ~(1 << c)
        done = completed[after]
        row_order = sorted(
            best_domain,
            key=lambda r: ((active & ~incompatible[c, r]).bit_count(), -relative_signature(n, c, r), -r),
            reverse=True,
        )
        for row in row_order:
            transitions += 1
            if transitions % 4096 == 0 and time_limit is not None and time.time() - started > time_limit:
                limit_reason = "time_limit"
                raise Limit
            a2 = active & ~incompatible[c, row]
            if a2 & done:
                nogood_prunes += 1
                continue
            snap = dsu.snapshot()
            radial = row_edges[c, row]
            for e in radial[1:]:
                dsu.union(radial[0], e)
            collapse = first_collapse()
            if collapse is not None:
                collapse_prunes += 1
                collapse_name_counts[collapse.split(":", 1)[0]] += 1
                dsu.rollback(snap)
                continue
            assignment[c] = row
            next_min = relative_signature(n, 0, row) if c == 0 else min_sig
            if search(after, a2, next_min):
                return True
            assignment.pop(c, None)
            dsu.rollback(snap)
        failed.add(key)
        return False

    witness = False
    row0_cases = 0
    try:
        # Explicitly branch on centre 0 first to make the rotational breaker sound.
        row0_domain = domains[0]
        if symmetry == "dihedral":
            row0_domain = [r for r in row0_domain if relative_signature(n, 0, r) == canonical_dihedral_signature(n, 0, r)]
        for r0 in sorted(row0_domain, key=lambda r: (relative_signature(n, 0, r), r)):
            row0_cases += 1
            sig0 = relative_signature(n, 0, r0)
            a0 = all_active & ~incompatible[0, r0]
            u0 = ((1 << n) - 1) & ~1
            if a0 & completed[u0]:
                nogood_prunes += 1
                continue
            snap = dsu.snapshot()
            radial = row_edges[0, r0]
            for e in radial[1:]:
                dsu.union(radial[0], e)
            collapse = first_collapse()
            if collapse is not None:
                collapse_prunes += 1
                collapse_name_counts[collapse.split(":", 1)[0]] += 1
                dsu.rollback(snap)
                continue
            assignment[0] = r0
            if search(u0, a0, sig0):
                witness = True
                break
            assignment.pop(0, None)
            dsu.rollback(snap)
    except Limit:
        witness = False

    supports = None
    if witness:
        supports = {str(c): [p for p in range(n) if assignment[c] >> p & 1] for c in sorted(assignment)}
    status = "EXACT_MASTER_SAT" if witness else ("LIMIT_EXHAUSTED" if limit_reason else "EXACT_MASTER_UNSAT")
    out = {
        "schema": "p97-single-k-collapse-master/v1",
        "n": n,
        "complete_berge_nogoods": len(generate_berge_family(list(range(n)), "all")["clauses"]) if include_berge else 0,
        "geometric_incidence_nogoods": geometric_incidence_nogoods(n)[1] if include_incidence else {},
        "additional_learned_nogoods": len(learned),
        "grouped_nogoods": m,
        "kalmanson_inequalities": len(kidx),
        "dynamic_kalmanson_dependence": "directed quotient-sum cycle" if two_k else "single zero form",
        "domain_size_per_centre": len(domains[0]),
        "raw_assignment_space": len(domains[0]) ** n,
        "symmetry": symmetry,
        "symmetry_breaker": (
            "centre 0 has minimum dihedral-canonical relative-row signature and is reflection-canonical"
            if symmetry == "dihedral" else
            "centre 0 has minimum relative-row signature" if symmetry == "rotation" else None
        ),
        "status": status,
        "supports": supports,
        "states": states,
        "transitions": transitions,
        "collapse_prunes": collapse_prunes,
        "collapse_kind_counts": dict(sorted(collapse_name_counts.items())),
        "nogood_prunes": nogood_prunes,
        "cache_hits": cache_hits,
        "memo_failed_states": len(failed),
        "row0_cases_tested": row0_cases,
        "limit_reason": limit_reason,
        "elapsed_seconds": time.time() - started,
    }
    out["payload_sha256"] = hashlib.sha256(cbytes(out)).hexdigest()
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, required=True)
    ap.add_argument("--learned-from", type=Path)
    ap.add_argument("--no-berge", action="store_true")
    ap.add_argument("--incidence", action="store_true")
    ap.add_argument("--single-k-only", action="store_true")
    ap.add_argument("--symmetry", choices=("dihedral", "rotation", "none"), default="dihedral")
    ap.add_argument("--time-limit", type=float)
    ap.add_argument("--state-limit", type=int)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    learned: list[list[list[int]]] = []
    if args.learned_from:
        source = json.loads(args.learned_from.read_text())
        learned = source.get("learned_nogoods", [])
    out = solve(args.n, learned, args.time_limit, args.state_limit, include_berge=not args.no_berge, include_incidence=args.incidence, symmetry=args.symmetry, two_k=not args.single_k_only)
    args.output.write_bytes(cbytes(out))
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
