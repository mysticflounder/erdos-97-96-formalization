#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <optional>
#include <queue>
#include <sstream>
#include <stdexcept>
#include <string>
#include <tuple>
#include <unordered_map>
#include <utility>
#include <vector>

using U64 = std::uint64_t;
using Clock = std::chrono::steady_clock;

struct Bits {
    std::vector<U64> w;
    Bits() = default;
    explicit Bits(std::size_t nwords) : w(nwords, 0) {}
};

static inline int popcount_and(const Bits &a, const Bits &b) {
    int total = 0;
    for (std::size_t i = 0; i < a.w.size(); ++i) total += std::popcount(a.w[i] & b.w[i]);
    return total;
}
static inline bool intersects(const Bits &a, const Bits &b) {
    for (std::size_t i = 0; i < a.w.size(); ++i) if (a.w[i] & b.w[i]) return true;
    return false;
}
static inline Bits and_not(const Bits &a, const Bits &b) {
    Bits out(a.w.size());
    for (std::size_t i = 0; i < a.w.size(); ++i) out.w[i] = a.w[i] & ~b.w[i];
    return out;
}
static inline void setbit(Bits &a, int i) { a.w[std::size_t(i) >> 6] |= U64(1) << (i & 63); }

struct RollbackDSU {
    std::vector<int> parent, size;
    struct Change { int b, a, old_size; bool merged; };
    std::vector<Change> stack;
    explicit RollbackDSU(int n) : parent(n), size(n,1) { std::iota(parent.begin(), parent.end(), 0); }
    int find(int x) const { while (parent[x] != x) x = parent[x]; return x; }
    std::size_t snapshot() const { return stack.size(); }
    void unite(int x, int y) {
        x=find(x); y=find(y);
        if (x==y) { stack.push_back({0,0,0,false}); return; }
        if (size[x] < size[y]) std::swap(x,y);
        stack.push_back({y,x,size[x],true});
        parent[y]=x; size[x]+=size[y];
    }
    void rollback(std::size_t snap) {
        while (stack.size()>snap) {
            auto ch=stack.back(); stack.pop_back();
            if (!ch.merged) continue;
            parent[ch.b]=ch.b; size[ch.a]=ch.old_size;
        }
    }
};

struct Clause { int centre_mask=0; std::vector<std::pair<int,int>> req; std::vector<int> need; };
struct KForm { std::array<int,4> e; }; // +,+,-,-

struct Solver {
    int n=0, m=0, words=0, edge_count=0;
    std::vector<Clause> clauses;
    std::vector<std::pair<int,int>> edges;
    std::vector<std::vector<int>> edge_index;
    std::vector<KForm> kforms;
    std::vector<std::vector<int>> domains;
    std::vector<std::vector<std::array<int,4>>> row_edges;
    std::vector<std::vector<Bits>> incompatible;
    std::vector<Bits> completed;
    // buckets[c][unassigned][0..3]
    std::vector<std::vector<std::array<Bits,4>>> buckets;
    RollbackDSU dsu;
    Bits all_active;
    std::vector<int> assignment;
    long long state_limit=-1;
    double time_limit=-1;
    Clock::time_point started;
    bool limit=false;
    long long states=0, transitions=0, collapse_prunes=0, nogood_prunes=0;
    std::unordered_map<int,long long> cycle_len_counts;
    int row0_cases=0;

    Solver(int n_, std::vector<Clause> cls) : n(n_), m((int)cls.size()), clauses(std::move(cls)), words((m+63)/64),
        edge_index(n_, std::vector<int>(n_,-1)), dsu(n_*(n_-1)/2), all_active(words), assignment(n_,-1) {
        build();
    }

    int edgeidx(int a,int b) const { if (a>b) std::swap(a,b); return edge_index[a][b]; }
    int relative_signature(int c,int row) const {
        int out=0;
        for(int p=0;p<n;++p) if ((row>>p)&1) out |= 1 << ((p-c+n)%n);
        return out;
    }
    int reflected_signature(int sig) const {
        int out=0;
        for(int k=1;k<n;++k) if ((sig>>k)&1) out |= 1 << ((n-k)%n);
        return out;
    }
    int canonical_dihedral_signature(int c,int row) const {
        int s=relative_signature(c,row); return std::min(s,reflected_signature(s));
    }

    void build() {
        int ei=0;
        for(int a=0;a<n;++a) for(int b=a+1;b<n;++b) { edge_index[a][b]=edge_index[b][a]=ei++; edges.push_back({a,b}); }
        edge_count=ei;
        for(int a=0;a<n;++a) for(int b=a+1;b<n;++b) for(int c=b+1;c<n;++c) for(int d=c+1;d<n;++d) {
            kforms.push_back({{edgeidx(a,c),edgeidx(b,d),edgeidx(a,b),edgeidx(c,d)}});
            kforms.push_back({{edgeidx(a,c),edgeidx(b,d),edgeidx(a,d),edgeidx(b,c)}});
        }
        domains.resize(n); row_edges.resize(n);
        for(int c=0;c<n;++c) {
            std::vector<int> pts; for(int p=0;p<n;++p) if(p!=c) pts.push_back(p);
            int sz=pts.size();
            for(int i=0;i<sz;++i) for(int j=i+1;j<sz;++j) for(int k=j+1;k<sz;++k) for(int l=k+1;l<sz;++l) {
                int row=(1<<pts[i])|(1<<pts[j])|(1<<pts[k])|(1<<pts[l]);
                domains[c].push_back(row);
                row_edges[c].push_back({edgeidx(c,pts[i]),edgeidx(c,pts[j]),edgeidx(c,pts[k]),edgeidx(c,pts[l])});
            }
        }
        for(int i=0;i<m;++i) setbit(all_active,i);
        incompatible.assign(n,{});
        for(int c=0;c<n;++c) {
            incompatible[c].reserve(domains[c].size());
            for(int row:domains[c]) {
                Bits bad(words);
                for(int i=0;i<m;++i) {
                    int need=clauses[i].need[c];
                    if(need && (need & ~row)) setbit(bad,i);
                }
                incompatible[c].push_back(std::move(bad));
            }
        }
        completed.assign(1<<n, Bits(words));
        // Populate by clause. A k-centre clause is complete in only 2^(n-k)
        // unassigned masks, far cheaper than scanning every clause per mask.
        for(int i=0;i<m;++i) {
            int cm=clauses[i].centre_mask;
            for(int um=0;um<(1<<n);++um) if((cm & um)==0) setbit(completed[um],i);
        }
        buckets.resize(n);
        for(int c=0;c<n;++c) {
            buckets[c].resize(1<<n);
            for(int um=0;um<(1<<n);++um) for(int q=0;q<4;++q) buckets[c][um][q]=Bits(words);
        }
        // Populate only masks containing each clause centre. This reduces the
        // n=11 build from O(n*2^n*m) to O(2^(n-1)*sum clause arities).
        for(int i=0;i<m;++i) {
            int cm=clauses[i].centre_mask;
            for(auto [c,mask]:clauses[i].req) {
                (void)mask;
                for(int um=0;um<(1<<n);++um) if((um>>c)&1) {
                    int after=um & ~(1<<c);
                    int rem=std::popcount((unsigned)(cm & after));
                    setbit(buckets[c][um][std::min(rem,3)],i);
                }
            }
        }
    }

    bool time_exceeded() const {
        if(time_limit<0) return false;
        return std::chrono::duration<double>(Clock::now()-started).count()>time_limit;
    }

    // Candidate-only structural master: exact geometric analysis is external.
    int sum_cycle_contradiction() { return 0; }

    std::tuple<int,std::vector<int>,std::array<int,5>> choose_centre(int unassigned,const Bits&active,int min_sig) {
        int best=-1; std::array<int,5> bestscore={-1,-1,-1,-1,-100000}; std::vector<int> bestdom;
        for(int c=0;c<n;++c) if((unassigned>>c)&1) {
            std::vector<int> allowed;
            for(int ri=0;ri<(int)domains[c].size();++ri) if(c==0 || canonical_dihedral_signature(c,domains[c][ri])>=min_sig) allowed.push_back(ri);
            std::array<int,5> score={popcount_and(active,buckets[c][unassigned][0]),popcount_and(active,buckets[c][unassigned][1]),popcount_and(active,buckets[c][unassigned][2]),0,-(int)allowed.size()};
            score[3]=score[0]+score[1]+score[2]+popcount_and(active,buckets[c][unassigned][3]);
            if(best<0 || score>bestscore){best=c;bestscore=score;bestdom=std::move(allowed);}
        }
        return {best,bestdom,bestscore};
    }

    bool search(int unassigned,const Bits&active,int min_sig) {
        ++states;
        if(state_limit>=0 && states>state_limit){limit=true;return false;}
        if((states&1023)==0 && time_exceeded()){limit=true;return false;}
        if(unassigned==0) return true;
        auto [c, allowed, bs]=choose_centre(unassigned,active,min_sig);
        int after=unassigned & ~(1<<c);
        struct Cand{int score, sig, row, ri;}; std::vector<Cand> order; order.reserve(allowed.size());
        for(int ri:allowed){Bits a2=and_not(active,incompatible[c][ri]);int score=0;for(U64 x:a2.w)score+=std::popcount(x);order.push_back({score,-relative_signature(c,domains[c][ri]),-domains[c][ri],ri});}
        std::sort(order.begin(),order.end(),[](auto const&a,auto const&b){return std::tie(a.score,a.sig,a.row)>std::tie(b.score,b.sig,b.row);});
        for(auto cand:order){
            if(limit) return false;
            ++transitions;
            Bits a2=and_not(active,incompatible[c][cand.ri]);
            if(intersects(a2,completed[after])){++nogood_prunes;continue;}
            auto snap=dsu.snapshot(); auto re=row_edges[c][cand.ri];
            for(int k=1;k<4;++k) dsu.unite(re[0],re[k]);
            int cyc=sum_cycle_contradiction();
            if(cyc){++collapse_prunes;++cycle_len_counts[cyc];dsu.rollback(snap);continue;}
            assignment[c]=domains[c][cand.ri];
            int next_min=(c==0)?relative_signature(0,domains[c][cand.ri]):min_sig;
            if(search(after,a2,next_min)) return true;
            assignment[c]=-1; dsu.rollback(snap);
        }
        return false;
    }

    bool solve() {
        started=Clock::now();
        std::vector<int> root;
        for(int ri=0;ri<(int)domains[0].size();++ri) if(relative_signature(0,domains[0][ri])==canonical_dihedral_signature(0,domains[0][ri])) root.push_back(ri);
        std::sort(root.begin(),root.end(),[&](int a,int b){return std::tie(domains[0][a],a)<std::tie(domains[0][b],b);});
        for(int ri:root){
            if(limit) break; ++row0_cases;
            int row=domains[0][ri], sig=relative_signature(0,row);
            Bits a0=and_not(all_active,incompatible[0][ri]); int u0=((1<<n)-1)&~1;
            if(intersects(a0,completed[u0])){++nogood_prunes;continue;}
            auto snap=dsu.snapshot(); auto re=row_edges[0][ri]; for(int k=1;k<4;++k) dsu.unite(re[0],re[k]);
            int cyc=sum_cycle_contradiction(); if(cyc){++collapse_prunes;++cycle_len_counts[cyc];dsu.rollback(snap);continue;}
            assignment[0]=row;
            if(search(u0,a0,sig)) return true;
            assignment[0]=-1; dsu.rollback(snap);
        }
        return false;
    }
};

std::vector<Clause> read_clauses(const std::string&path,int&n){
    std::ifstream f(path); if(!f) throw std::runtime_error("cannot open clause file"); int m;f>>n>>m;std::vector<Clause> out(m);
    for(int i=0;i<m;++i){out[i].need.assign(n,0);int k;f>>k;for(int j=0;j<k;++j){int c,mask;f>>c>>mask;out[i].req.push_back({c,mask});out[i].need[c]=mask;out[i].centre_mask|=1<<c;}}
    return out;
}

int main(int argc,char**argv){
    if(argc<3){std::cerr<<"usage: solver CLAUSES OUT [state_limit] [time_limit]\n";return 2;}
    auto wall_started=Clock::now();
    int n;auto cls=read_clauses(argv[1],n);auto build_started=Clock::now();Solver s(n,std::move(cls));double build_elapsed=std::chrono::duration<double>(Clock::now()-build_started).count();if(argc>3)s.state_limit=std::stoll(argv[3]);if(argc>4)s.time_limit=std::stod(argv[4]);
    bool sat=s.solve();double elapsed=std::chrono::duration<double>(Clock::now()-s.started).count();double wall_elapsed=std::chrono::duration<double>(Clock::now()-wall_started).count();
    std::ofstream o(argv[2]);
    std::string status=sat?"EXACT_MASTER_SAT":(s.limit?"LIMIT_EXHAUSTED":"EXACT_MASTER_UNSAT");
    o<<"{\n  \"schema\": \"p97-structural-row-master-fast-cpp/v1\",\n  \"n\": "<<s.n<<",\n  \"clauses\": "<<s.m<<",\n  \"kalmanson_inequalities\": "<<s.kforms.size()<<",\n  \"status\": \""<<status<<"\",\n  \"states\": "<<s.states<<",\n  \"transitions\": "<<s.transitions<<",\n  \"sum_cycle_prunes\": "<<s.collapse_prunes<<",\n  \"nogood_prunes\": "<<s.nogood_prunes<<",\n  \"row0_cases_tested\": "<<s.row0_cases<<",\n  \"build_seconds\": "<<build_elapsed<<",\n  \"elapsed_seconds\": "<<elapsed<<",\n  \"wall_seconds\": "<<wall_elapsed<<",\n  \"cycle_length_counts\": {";
    bool first=true;for(auto const&[k,v]:s.cycle_len_counts){if(!first)o<<",";first=false;o<<"\""<<k<<"\":"<<v;}o<<"},\n  \"supports\": ";
    if(!sat)o<<"null\n";else{o<<"{";for(int c=0;c<s.n;++c){if(c)o<<",";o<<"\""<<c<<"\":[";bool ff=true;for(int p=0;p<s.n;++p)if((s.assignment[c]>>p)&1){if(!ff)o<<",";ff=false;o<<p;}o<<"]";}o<<"}\n";}o<<"}\n";
    std::cout<<status<<" states="<<s.states<<" transitions="<<s.transitions<<" cycles="<<s.collapse_prunes<<" build="<<build_elapsed<<" search="<<elapsed<<" wall="<<wall_elapsed<<"\n";
    return 0;
}
