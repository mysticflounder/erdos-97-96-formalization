#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

def read_bank(p:Path):
    with p.open() as f:
        n,m=map(int,f.readline().split()); s=set()
        for _ in range(m):
            xs=list(map(int,f.readline().split()));k=xs[0]
            assert len(xs)==1+2*k
            s.add(tuple((xs[1+2*i],xs[2+2*i]) for i in range(k)))
        assert len(s)==m
    return n,s

def group(atoms):
    g={}
    for c,p in atoms:g[c]=g.get(c,0)|(1<<p)
    return tuple(sorted(g.items()))

def write(p:Path,n:int,s:set):
    with p.open('w') as f:
        f.write(f'{n} {len(s)}\n')
        for cl in sorted(s):
            f.write(str(len(cl))+''.join(f' {c} {m}' for c,m in cl)+'\n')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,required=True);ap.add_argument('--r2',type=Path,required=True);ap.add_argument('--r3',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--manifest',type=Path,required=True);a=ap.parse_args()
    n,base=read_bank(a.base); extra=set(); records=[]
    for name,p,r in [('r2',a.r2,2),('r3',a.r3,3)]:
        d=json.loads(p.read_text()); imgs={group(map(tuple,x)) for x in d['dihedral_images']}
        assert len(imgs)==20==d['dihedral_orbit_size'];extra|=imgs
        records.append({'name':name,'r':r,'orbit_size':len(imgs),'payload_sha256':d['payload_sha256']})
    assert len(extra)==40 and base.isdisjoint(extra)
    allc=base|extra;assert len(allc)==9280
    write(a.output,n,allc); h=hashlib.sha256(a.output.read_bytes()).hexdigest()
    out={'schema':'p97-n10-static-bank-reconstruction/v1','n':n,'base_clauses':len(base),'chain_clauses':len(extra),'total_clauses':len(allc),'sha256':h,'cores':records}
    a.manifest.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
if __name__=='__main__':main()
