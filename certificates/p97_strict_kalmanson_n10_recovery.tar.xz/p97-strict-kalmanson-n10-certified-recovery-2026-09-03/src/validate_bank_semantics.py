#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json
from itertools import combinations
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from berge_triangle_kalmanson_classifier import classify
from berge_triangle_nogood_family import generate as generate_berge

def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def read_bank(p:Path):
    with p.open() as f:
        n,m=map(int,f.readline().split()); out=[]
        for _ in range(m):
            xs=list(map(int,f.readline().split())); k=xs[0]
            assert len(xs)==1+2*k
            cl=tuple((xs[1+2*i],xs[2+2*i]) for i in range(k))
            assert tuple(sorted(cl))==cl
            out.append(cl)
        assert not f.read().strip()
    assert len(out)==m and len(set(out))==m
    return n,set(out)
def group(atoms):
    g={}
    for c,p in atoms:g[c]=g.get(c,0)|(1<<p)
    return tuple(sorted(g.items()))
def shared(n):
    out=set()
    for a,b,c,d in combinations(range(n),4):
        for x,y,p,q in ((a,b,c,d),(c,d,a,b),(a,d,b,c),(b,c,a,d)):
            out.add(group(((x,p),(x,q),(y,p),(y,q))))
    return out
def flat_to_grouped(flat):
    return group((flat[i],flat[i+1]) for i in range(0,len(flat),2))
def canonical_chain_atoms(n,r):
    atoms={(1,0),(1,r+1),(0,r),(0,n-1),(n-1,n-2),(n-1,0)}
    for k in range(r+1,n-1):atoms|={(k,k-1),(k,k+1)}
    return atoms

def main():
    n=10
    cls=classify()
    assert cls['linear_orders']==720
    assert len(cls['orbits'])==13
    bad=[r for r in cls['orbits'] if r['verdict'].startswith('INFEASIBLE')]
    good=[r for r in cls['orbits'] if not r['verdict'].startswith('INFEASIBLE')]
    assert len(bad)==4 and len(good)==9
    assert sorted(r['certificate']['size'] for r in bad)==[2,2,2,3]
    for r in bad:
        cert=r['certificate']
        assert all(w>0 for w in cert['weights'])
        assert all(x==0 for x in cert['sum_vector'])
        assert len(cert['indices'])==cert['size']==len(cert['inequalities'])==len(cert['weights'])
    berge_payload=generate_berge(list(range(n)),'all')
    berge={flat_to_grouped(x) for x in berge_payload['clauses']}
    assert len(berge)==8400==berge_payload['unique_nogoods']
    sh=shared(n); assert len(sh)==840
    nb,base=read_bank(ROOT/'generated/regenerated-clauses-n10-shared-berge.txt')
    assert nb==n and base==berge|sh and len(base)==9240 and berge.isdisjoint(sh)
    extra=set(); core_records=[]
    for name,r in [('r2',2),('r3',3)]:
        d=json.loads((ROOT/f'generated/core-{name}.json').read_text())
        can=canonical_chain_atoms(n,r)
        assert set(map(tuple,d['hit_core']))==can
        imgs={group(map(tuple,img)) for img in d['dihedral_images']}
        assert len(imgs)==d['dihedral_orbit_size']==20
        extra|=imgs
        core_records.append({'name':name,'r':r,'canonical_atoms':len(can),'orbit_size':len(imgs),'payload_sha256':d['payload_sha256']})
    assert len(extra)==40 and base.isdisjoint(extra)
    nf,full=read_bank(ROOT/'generated/independently-reconstructed-clauses-n10-static.txt')
    assert nf==n and full==base|extra and len(full)==9280
    assert sha(ROOT/'generated/independently-reconstructed-clauses-n10-static.txt')=='dffbade583eb1576055157ef8dbd8c2a703c399816b5179ded2d20a8ed97d8f7'
    out={
      'schema':'p97-n10-strict-kalmanson-bank-semantic-audit/v1','status':'PASS','n':n,
      'berge_clauses':len(berge),'shared_pair_clauses':len(sh),'chain_clauses':len(extra),'total_clauses':len(full),
      'berge_order_orbits':len(cls['orbits']),'berge_infeasible_orbits':len(bad),'berge_feasible_relaxation_orbits':len(good),
      'certificate_sizes':sorted(r['certificate']['size'] for r in bad),'bank_sha256':sha(ROOT/'generated/independently-reconstructed-clauses-n10-static.txt'),
      'cores':core_records,
    }
    p=ROOT/'results/bank-semantic-audit.json';p.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps(out,sort_keys=True,indent=2))
if __name__=='__main__':main()
