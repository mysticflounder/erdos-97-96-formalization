#!/usr/bin/env python3
from pathlib import Path
import argparse
ap=argparse.ArgumentParser();ap.add_argument('source',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args()
with a.source.open() as f:
    n,m=map(int,f.readline().split()); rows=[]
    for _ in range(m):
        xs=list(map(int,f.readline().split()));k=xs[0];l=[]
        for i in range(k):
            c,mask=xs[1+2*i],xs[2+2*i]
            l += [c*n+p+1 for p in range(n) if mask>>p&1]
        rows.append(l)
with a.output.open('w') as g:
    g.write(f'p97monotone {n} {m}\n')
    for r in rows:g.write(' '.join(map(str,r))+' 0\n')
