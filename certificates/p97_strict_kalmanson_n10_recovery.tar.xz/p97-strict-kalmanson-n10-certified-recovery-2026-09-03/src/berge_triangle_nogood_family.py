#!/usr/bin/env python3
"""Generate compact source-valid Berge-triangle Kalmanson no-good clauses.

A clause consists of the six positive selected-row membership atoms encoding
three rows that pairwise share three distinct support vertices.  The cyclic
order type is rejected exactly when the companion classifier supplies a strict
Kalmanson dependency.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from itertools import combinations, permutations
from pathlib import Path
from typing import Any, Iterable

from berge_triangle_kalmanson_classifier import LABELS, canonical_order, classify

ROW_ATOMS = (
    ("A", "Y"),
    ("A", "Z"),
    ("B", "X"),
    ("B", "Y"),
    ("C", "X"),
    ("C", "Z"),
)


def canonical_json_bytes(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()


def parse_order(text: str) -> list[int]:
    values = [int(item) for item in text.split(",")]
    if len(values) != len(set(values)):
        raise ValueError("cyclic order contains duplicate labels")
    if len(values) < 6:
        raise ValueError("at least six labels are required")
    return values


def forbidden_orbits(mode: str) -> tuple[set[tuple[str, ...]], dict[tuple[str, ...], int]]:
    classification = classify()
    selected: set[tuple[str, ...]] = set()
    sizes: dict[tuple[str, ...], int] = {}
    for record in classification["orbits"]:
        verdict = record["verdict"]
        if not verdict.startswith("INFEASIBLE"):
            continue
        size = int(record["certificate"]["size"])
        if mode == "two" and size != 2:
            continue
        representative = tuple(record["representative_order"])
        selected.add(representative)
        sizes[representative] = size
    return selected, sizes


def compact_clause(mapping: dict[str, int]) -> tuple[int, ...]:
    atoms = sorted((mapping[center], mapping[point]) for center, point in ROW_ATOMS)
    return tuple(value for atom in atoms for value in atom)


def generate(order: list[int], mode: str) -> dict[str, Any]:
    bad_orbits, sizes = forbidden_orbits(mode)
    bad_linear_orders = [
        abstract_order
        for abstract_order in permutations(LABELS)
        if canonical_order(abstract_order) in bad_orbits
    ]

    clauses: set[tuple[int, ...]] = set()
    for positions in combinations(range(len(order)), 6):
        physical = [order[index] for index in positions]
        for abstract_order in bad_linear_orders:
            mapping = {abstract_order[index]: physical[index] for index in range(6)}
            clauses.add(compact_clause(mapping))

    ordered_clauses = sorted(clauses)
    payload: dict[str, Any] = {
        "schema": "p97-berge-triangle-kalmanson-nogood-family/v1",
        "mode": mode,
        "carrier_order": order,
        "n": len(order),
        "clause_encoding": "flat [center,point] x 6; all six atoms are negated",
        "clause_width": 6,
        "forbidden_order_orbits": [
            {
                "representative_order": list(representative),
                "kalmanson_certificate_size": sizes[representative],
            }
            for representative in sorted(bad_orbits)
        ],
        "forbidden_linear_orders": len(bad_linear_orders),
        "six_subsets": sum(1 for _ in combinations(order, 6)),
        "raw_role_assignments": len(bad_linear_orders)
        * sum(1 for _ in combinations(order, 6)),
        "unique_nogoods": len(ordered_clauses),
        "clauses": [list(clause) for clause in ordered_clauses],
    }
    payload["family_sha256"] = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    return payload


def main() -> int:
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--n", type=int)
    group.add_argument("--order")
    parser.add_argument("--mode", choices=("two", "all"), default="all")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    order = list(range(args.n)) if args.n is not None else parse_order(args.order)
    payload = generate(order, args.mode)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(canonical_json_bytes(payload))
    print(
        json.dumps(
            {
                key: payload[key]
                for key in (
                    "mode",
                    "n",
                    "forbidden_linear_orders",
                    "six_subsets",
                    "raw_role_assignments",
                    "unique_nogoods",
                    "family_sha256",
                )
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
