#!/usr/bin/env python3
from __future__ import annotations
import json,sys
from pathlib import Path
r=Path(sys.argv[1]); full=(len(sys.argv)>2 and sys.argv[2]=='--full-nosym')
def load(n):return json.loads((r/n).read_text())
slow=load('slow.json');fast=load('fast.json');sym=load('row-csp-sym.json')
for d in (slow,fast):
    assert d['status']=='EXACT_MASTER_UNSAT';assert d['n']==10 and d['clauses']==9280
    assert d['states']==57228 and d['transitions']==4744373 and d['row0_cases_tested']==66
assert sym['status']=='UNSAT' and sym['n']==10 and sym['clauses']==9280 and sym['row0_cases']==66
if full:
    nosym=load('row-csp-nosym.json');assert nosym['status']=='UNSAT' and nosym['row0_cases']==126
print(json.dumps({'status':'PASS','slow':slow['status'],'fast':fast['status'],'independent_sym':sym['status'],'independent_nosym':load('row-csp-nosym.json')['status'] if full else 'NOT_RUN'},sort_keys=True))
