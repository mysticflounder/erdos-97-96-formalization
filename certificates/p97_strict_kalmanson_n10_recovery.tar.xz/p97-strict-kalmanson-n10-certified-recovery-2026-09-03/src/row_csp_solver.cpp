#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>
using namespace std;

struct GClause { uint16_t centers=0; array<uint16_t,11> req{}; };

struct Solver {
 int n=0,m=0,W=0;
 vector<GClause> clauses;
 vector<vector<uint16_t>> rows;
 vector<vector<vector<uint64_t>>> incompat; // [c][r][word]
 vector<vector<uint64_t>> involved; // [c][word]
 vector<vector<uint64_t>> completed; // [unassigned][word]
 vector<vector<int>> row_order;
 array<int,11> assignment{};
 uint16_t sig0=0; bool use_symmetry=true;
 uint64_t nodes=0,trials=0,word_ops=0,conflicts=0,row0_cases=0,max_depth=0;
 double limit_seconds=0; uint64_t limit_nodes=0; bool limited=false;
 chrono::steady_clock::time_point started;

 uint16_t relative_sig(int c,uint16_t row) const { uint16_t s=0; for(int p=0;p<n;p++) if(row>>p&1) s|=uint16_t(1)<<((p-c+n)%n); return s; }
 uint16_t reflect_sig(uint16_t s) const { uint16_t t=0; for(int k=1;k<n;k++) if(s>>k&1)t|=uint16_t(1)<<((n-k)%n); return t; }
 uint16_t canonical_sig(int c,uint16_t row) const { auto s=relative_sig(c,row); return min(s,reflect_sig(s)); }

 bool load(const string& path){
  ifstream in(path); if(!in)return false; string tag; in>>tag>>n>>m; if(tag!="p97monotone")return false; string line;getline(in,line);
  clauses.resize(m);
  for(int i=0;i<m;i++){
   getline(in,line);istringstream ss(line);int x;
   while(ss>>x&&x){--x;int c=x/n,p=x%n;if(c==p)return false;clauses[i].centers|=uint16_t(1)<<c;clauses[i].req[c]|=uint16_t(1)<<p;}
  }
  W=(m+63)/64; rows.resize(n); row_order.resize(n); assignment.fill(-1);
  for(int c=0;c<n;c++){
   vector<int> ps;for(int p=0;p<n;p++)if(p!=c)ps.push_back(p);
   for(int a=0;a<(int)ps.size();a++)for(int b=a+1;b<(int)ps.size();b++)for(int d=b+1;d<(int)ps.size();d++)for(int e=d+1;e<(int)ps.size();e++)rows[c].push_back((uint16_t(1)<<ps[a])|(uint16_t(1)<<ps[b])|(uint16_t(1)<<ps[d])|(uint16_t(1)<<ps[e]));
  }
  involved.assign(n,vector<uint64_t>(W));
  incompat.resize(n);
  for(int c=0;c<n;c++){
   incompat[c].assign(rows[c].size(),vector<uint64_t>(W));
   for(int i=0;i<m;i++)if(clauses[i].centers>>c&1){
    involved[c][i>>6]|=uint64_t(1)<<(i&63);
    for(size_t r=0;r<rows[c].size();r++)if((clauses[i].req[c]&~rows[c][r])!=0)incompat[c][r][i>>6]|=uint64_t(1)<<(i&63);
   }
   vector<pair<int,int>> ord;
   for(size_t r=0;r<rows[c].size();r++){int k=0;for(auto z:incompat[c][r])k+=popcount(z);ord.push_back({-k,(int)r});}
   sort(ord.begin(),ord.end());for(auto [x,r]:ord)row_order[c].push_back(r); // most killing first
  }
  completed.assign(1<<n,vector<uint64_t>(W));
  for(int um=0;um<(1<<n);um++)for(int i=0;i<m;i++)if((clauses[i].centers&um)==0)completed[um][i>>6]|=uint64_t(1)<<(i&63);
  return true;
 }
 bool time_hit(){if(limit_nodes&&nodes>=limit_nodes){limited=true;return true;} if(limit_seconds>0&&(trials&1023)==0){double s=chrono::duration<double>(chrono::steady_clock::now()-started).count();if(s>=limit_seconds){limited=true;return true;}}return false;}
 bool any_and(const vector<uint64_t>&a,const vector<uint64_t>&b){for(int w=0;w<W;w++){word_ops++;if(a[w]&b[w])return true;}return false;}
 int pop_and(const vector<uint64_t>&a,const vector<uint64_t>&b){int z=0;for(int w=0;w<W;w++){word_ops++;z+=popcount(a[w]&b[w]);}return z;}
 vector<uint64_t> apply(const vector<uint64_t>&active,int c,int ri){vector<uint64_t> out(W);auto &bad=incompat[c][ri];for(int w=0;w<W;w++){word_ops++;out[w]=active[w]&~bad[w];}return out;}
 bool active_empty(const vector<uint64_t>&a)const{for(auto x:a)if(x)return false;return true;}

 bool search(uint16_t unassigned,const vector<uint64_t>&active,int depth){
  nodes++;max_depth=max<uint64_t>(max_depth,depth);if(time_hit())return false;
  if(!unassigned)return active_empty(active);
  if(active_empty(active)){
   for(int c=0;c<n;c++)if(unassigned>>c&1){for(int ri:row_order[c])if(!use_symmetry||c==0||canonical_sig(c,rows[c][ri])>=sig0){assignment[c]=ri;break;}}
   return true;
  }
  int best=-1;tuple<int,int,int> bestscore{-1,-1,-1};
  for(int c=0;c<n;c++)if(unassigned>>c&1){
   uint16_t after=unassigned&~(uint16_t(1)<<c);
   int immediate=0,total=0;
   for(int w=0;w<W;w++){word_ops+=2;immediate+=popcount(active[w]&completed[after][w]&involved[c][w]);total+=popcount(active[w]&involved[c][w]);}
   int admissible=0;for(int ri:row_order[c])if(!use_symmetry||c==0||canonical_sig(c,rows[c][ri])>=sig0)admissible++;
   auto sc=make_tuple(immediate,total,-admissible);if(best<0||sc>bestscore){best=c;bestscore=sc;}
  }
  uint16_t after=unassigned&~(uint16_t(1)<<best);
  struct Cand{int ri;int kept;};vector<Cand> cs;cs.reserve(rows[best].size());
  for(int ri:row_order[best]){
   if(use_symmetry&&best!=0&&canonical_sig(best,rows[best][ri])<sig0)continue;
   trials++;if(time_hit())return false;
   auto next=apply(active,best,ri);
   if(any_and(next,completed[after])){conflicts++;continue;}
   int kept=0;for(auto x:next)kept+=popcount(x);
   cs.push_back({ri,kept});
  }
  sort(cs.begin(),cs.end(),[](auto a,auto b){if(a.kept!=b.kept)return a.kept<b.kept;return a.ri<b.ri;});
  for(auto ca:cs){
   trials++;if(time_hit())return false;
   auto next=apply(active,best,ca.ri);assignment[best]=ca.ri;
   if(search(after,next,depth+1))return true;
   assignment[best]=-1;if(limited)return false;
  }
  return false;
 }
 int run(double sec,uint64_t maxnodes){
  limit_seconds=sec;limit_nodes=maxnodes;started=chrono::steady_clock::now();
  vector<uint64_t> all(W,~uint64_t(0));if(m%64)all.back()=(uint64_t(1)<<(m%64))-1;
  vector<int> r0;for(int ri:row_order[0])if(!use_symmetry || relative_sig(0,rows[0][ri])==canonical_sig(0,rows[0][ri]))r0.push_back(ri);
  sort(r0.begin(),r0.end(),[&](int a,int b){auto x=relative_sig(0,rows[0][a]),y=relative_sig(0,rows[0][b]);return x!=y?x<y:a<b;});
  bool sat=false;for(int ri:r0){row0_cases++;sig0=relative_sig(0,rows[0][ri]);assignment[0]=ri;auto a=apply(all,0,ri);uint16_t um=((1<<n)-1)&~1;if(any_and(a,completed[um])){conflicts++;continue;}if(search(um,a,1)){sat=true;break;}assignment[0]=-1;if(limited)break;}
  double elapsed=chrono::duration<double>(chrono::steady_clock::now()-started).count();
  cout<<"{\n  \"schema\": \"p97-row-csp-bitset/v1\",\n  \"n\": "<<n<<",\n  \"clauses\": "<<m<<",\n  \"status\": \""<<(sat?"SAT":limited?"LIMIT_EXHAUSTED":"UNSAT")<<"\",\n  \"elapsed_seconds\": "<<elapsed<<",\n  \"nodes\": "<<nodes<<",\n  \"row_trials\": "<<trials<<",\n  \"word_ops\": "<<word_ops<<",\n  \"conflicts\": "<<conflicts<<",\n  \"row0_cases\": "<<row0_cases<<",\n  \"max_depth\": "<<max_depth<<",\n  \"supports\": ";
  if(!sat)cout<<"null\n";else{cout<<"{\n";for(int c=0;c<n;c++){uint16_t r=rows[c][assignment[c]];cout<<"    \""<<c<<"\": [";bool f=1;for(int p=0;p<n;p++)if(r>>p&1){if(!f)cout<<",";f=0;cout<<p;}cout<<"]"<<(c+1<n?",":"")<<"\n";}cout<<"  }\n";}cout<<"}\n";
  return sat?10:limited?20:0;
 }
};
int main(int argc,char**argv){if(argc<2)return 2;Solver s;if(!s.load(argv[1]))return 2;if(argc>4 && string(argv[4])=="nosym")s.use_symmetry=false;return s.run(argc>2?stod(argv[2]):0,argc>3?stoull(argv[3]):0);}
