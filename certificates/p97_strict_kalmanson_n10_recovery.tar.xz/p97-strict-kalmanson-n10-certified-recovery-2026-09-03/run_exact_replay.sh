#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
CXX="${CXX:-g++}"
FLAGS=(-std=c++20 -O3 -DNDEBUG -Wall -Wextra -Wpedantic)
mkdir -p "$ROOT/replay-bin" "$ROOT/replay-results"
"$CXX" "${FLAGS[@]}" "$ROOT/src/structural_row_master.cpp" -o "$ROOT/replay-bin/structural_row_master"
"$CXX" "${FLAGS[@]}" "$ROOT/src/structural_row_master_fast.cpp" -o "$ROOT/replay-bin/structural_row_master_fast"
"$CXX" "${FLAGS[@]}" "$ROOT/src/row_csp_solver.cpp" -o "$ROOT/replay-bin/row_csp_solver"
python3 "$ROOT/src/generate_strict_kalmanson_banks.py" --n 10 \
  --output "$ROOT/replay-results/base.txt" \
  --manifest "$ROOT/replay-results/base.manifest.json"
python3 "$ROOT/src/reconstruct_full_bank.py" \
  --base "$ROOT/replay-results/base.txt" \
  --r2 "$ROOT/generated/core-r2.json" \
  --r3 "$ROOT/generated/core-r3.json" \
  --output "$ROOT/replay-results/full.txt" \
  --manifest "$ROOT/replay-results/full.manifest.json"
cmp "$ROOT/replay-results/base.txt" "$ROOT/generated/regenerated-clauses-n10-shared-berge.txt"
cmp "$ROOT/replay-results/full.txt" "$ROOT/generated/independently-reconstructed-clauses-n10-static.txt"
python3 "$ROOT/src/to_monotone.py" "$ROOT/replay-results/full.txt" "$ROOT/replay-results/full.p97monotone"
"$ROOT/replay-bin/structural_row_master" "$ROOT/replay-results/full.txt" "$ROOT/replay-results/structural-slow.json" 20000000 120
"$ROOT/replay-bin/structural_row_master_fast" "$ROOT/replay-results/full.txt" "$ROOT/replay-results/structural-fast.json" 20000000 120
"$ROOT/replay-bin/row_csp_solver" "$ROOT/replay-results/full.p97monotone" 120 0 > "$ROOT/replay-results/row-csp-sym.json"
if [[ "${1:-}" == "--no-symmetry" ]]; then
  "$ROOT/replay-bin/row_csp_solver" "$ROOT/replay-results/full.p97monotone" 300 0 nosym > "$ROOT/replay-results/row-csp-nosym.json"
fi
python3 - "$ROOT/replay-results" "${1:-}" <<'PY'
import json, pathlib, sys
r=pathlib.Path(sys.argv[1]); full=(len(sys.argv)>2 and sys.argv[2]=='--no-symmetry')
slow=json.loads((r/'structural-slow.json').read_text())
fast=json.loads((r/'structural-fast.json').read_text())
sym=json.loads((r/'row-csp-sym.json').read_text())
assert slow['status']==fast['status']=='EXACT_MASTER_UNSAT'
assert slow['states']==fast['states']==57228
assert slow['transitions']==fast['transitions']==4744373
assert slow['row0_cases_tested']==fast['row0_cases_tested']==66
assert sym['status']=='UNSAT' and sym['row0_cases']==66
if full:
    ns=json.loads((r/'row-csp-nosym.json').read_text())
    assert ns['status']=='UNSAT' and ns['row0_cases']==126 and ns['max_depth']==9
print('PASS')
PY
