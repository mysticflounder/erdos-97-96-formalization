#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
EXPECTED_BANK='dffbade583eb1576055157ef8dbd8c2a703c399816b5179ded2d20a8ed97d8f7'
def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
# Integrity ledger
for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
    h, rel=line.split('  ',1); p=ROOT/rel
    assert p.is_file(), rel
    assert sha(p)==h, rel
# Bank provenance and independent reconstruction
assert (ROOT/'generated/original-clauses-n10-shared-berge.txt').read_bytes()==(ROOT/'generated/regenerated-clauses-n10-shared-berge.txt').read_bytes()
assert (ROOT/'generated/original-clauses-n10-static-cegar.txt').read_bytes()==(ROOT/'generated/independently-reconstructed-clauses-n10-static.txt').read_bytes()
assert (ROOT/'generated/full.txt').read_bytes()==(ROOT/'generated/original-clauses-n10-static-cegar.txt').read_bytes()
assert sha(ROOT/'generated/full.txt')==EXPECTED_BANK
# Semantic validators
subprocess.run([sys.executable,str(ROOT/'src/validate_bank_semantics.py')],cwd=ROOT/'src',check=True,stdout=subprocess.DEVNULL)
subprocess.run([sys.executable,str(ROOT/'src/validate_incremental_witnesses.py')],cwd=ROOT/'src',check=True,stdout=subprocess.DEVNULL)
# Result records
slow=json.loads((ROOT/'results/fresh-structural-slow.json').read_text())
fast=json.loads((ROOT/'results/fresh-structural-fast.json').read_text())
fast2=json.loads((ROOT/'results/final-structural-fast-replay.json').read_text())
sym=json.loads((ROOT/'results/final-row-csp-sym-replay.json').read_text())
ns=json.loads((ROOT/'results/final-row-csp-nosym-replay.json').read_text())
for d in (slow,fast,fast2):
    assert d['status']=='EXACT_MASTER_UNSAT' and d['n']==10 and d['clauses']==9280
    assert d['states']==57228 and d['transitions']==4744373 and d['row0_cases_tested']==66
assert sym['status']=='UNSAT' and sym['row0_cases']==66 and sym['max_depth']==8
assert ns['status']=='UNSAT' and ns['row0_cases']==126 and ns['max_depth']==9
print(json.dumps({'schema':'p97-n10-certified-recovery-bundle/v1','status':'PASS','bank_sha256':EXPECTED_BANK,'structural_status':fast2['status'],'independent_symmetry_status':sym['status'],'independent_no_symmetry_status':ns['status'],'row0_cases_without_symmetry':ns['row0_cases']},indent=2,sort_keys=True))
