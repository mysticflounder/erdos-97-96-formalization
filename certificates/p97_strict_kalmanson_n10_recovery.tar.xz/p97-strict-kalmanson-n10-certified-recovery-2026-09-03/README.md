# P97 strict-Kalmanson n=10 certified recovery bundle

This bundle repairs the provenance gap in the earlier n=10 announcement. The original files existed only in a session-local runtime and were not deposited in the repository or nthdegree. The bundle contains the recovered inputs, independent bank reconstruction, semantic validators, three exact search implementations, fresh result records, and incremental SAT controls.

Run the fast integrity and semantic replay:

```bash
python3 verify_bundle.py
```

Run fresh compiled exact searches using the 66-case reflection reduction:

```bash
./run_exact_replay.sh
```

Run the additional all-126-row-0 no-symmetry search:

```bash
./run_exact_replay.sh --no-symmetry
```

The second command is slower. Precompiled binaries are included only as convenience; the replay script recompiles from source.

The computational theorem is finite and exact at n=10, but it is not a Lean proof and does not by itself close P97. See `checkpoint.md` for the precise statement and claim boundary.
